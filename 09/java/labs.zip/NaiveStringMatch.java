public class NaiveStringMatch implements StringMatch {
    public int charMatchCount = 0;
    public int match(String text, String pattern) {

	    char[] txtArr = text.toCharArray();
            char[] patArr = pattern.toCharArray();
		System.out.println("text array " + txtArr.toString());
System.out.println("pattern array " +patArr.toString());
            int tLen = txtArr.length;
            int pLen = patArr.length;

	        if (tLen == 0 && pLen >0) {
		charMatchCount = -1;
                     return -1;
               }

	        if (tLen == 0 && pLen  ==0) {
			charMatchCount = -1;
                     return 0;
               }

             for (int i = 0; i < tLen - pLen; i++) {

               charMatchCount = 0;
               for (int j = 0; j < pLen; j++) {

                     if (patArr[j] != txtArr[i + j]) {
                          break;
                     }
                     charMatchCount++;

               }
               if (charMatchCount == pLen) {
                     System.out.print("String found at "+(i+1)+" position!!");

                     break;
               }

		

            }
	System.out.println("char match " + charMatchCount);

        return charMatchCount;
    }
}
