import org.junit.Before;

public class RKStringMatchTest extends StringMatchTest {
    @Before
    public void setUp() {
        matcher = new RKStringMatch();
    }
}
