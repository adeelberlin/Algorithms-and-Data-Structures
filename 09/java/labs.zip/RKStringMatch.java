public class RKStringMatch implements StringMatch {
    public int match(String text, String pattern) {
        return 0;
    }
}
