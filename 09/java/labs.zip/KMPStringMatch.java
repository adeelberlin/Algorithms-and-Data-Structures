public class KMPStringMatch implements StringMatch {
    public int match(String text, String pattern) {
        return -1;
    }
}
